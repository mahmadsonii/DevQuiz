# Омӯзиши Барномасозӣ Android App

Лоиҳаи Android барои табдил додани сайти HTML/JS/CSS ба APK.

## 📁 Файлҳои веб
Файлҳои худро ба папкаи `app/src/main/assets/` илова кун:
- index.html ✅
- style.css ✅
- script.js ✅
- ва дигар файлҳо...

## 🚀 APK сохтан
1. Репоро ба GitHub push кун
2. Actions → "Build APK" → "Run workflow"
3. Баъд аз ~5 дақиқа APK омода мешавад
4. Artifacts → OmuzishiApp-debug → зеркашӣ кун
